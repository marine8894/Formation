(function moyenneNotes (){
    let dc1 = parseInt(prompt("Note DC1 : "));
    let dc2 = parseInt(prompt("Note DC2 : "));
    let ds = parseInt(prompt("Note DS : "));
    var moyenne = (dc1 + dc2 + ds)/3;
    alert("La moyenne des notes est de : " + moyenne);
})();
