/*const bouton = document.getElementById("bouton");
            
const Moyenne = () => {
    var dc1 = document.getElementById("dc1").value;
    var dc2 = document.getElementById("dc2").value;
    var ds = document.getElementById("ds").value;
    var moyenne = (parseInt(dc1) + parseInt(dc2) + parseInt(ds))/3;
    alert("La moyenne des notes est de : " + moyenne);
}*/